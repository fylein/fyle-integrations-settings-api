# frozen_string_literal: true

{
  title: 'Gusto',

  connection: {
    fields: [
      {
        name: 'client_id',
        optional: false,
        hint: "Refer <a href = 'https://gusto." \
              "stoplight.io/docs/api/ZG9jOjE4MTQ2MDA-authentication' target=" \
              "'blank'>API documentation</a> for more information"
      },
      {
        name: 'client_secret',
        optional: false,
        control_type: 'password',
        hint: "Refer <a href = 'https://gusto." \
              "stoplight.io/docs/api/ZG9jOjE4MTQ2MDA-authentication' target=" \
              "'blank'>API documentation</a> for more information"
      },
      {
        name: 'environment',
        control_type: 'select',
        pick_list: [['Sandbox', 'https://api.gusto-demo.com'],
                    ['Production', 'https://api.gusto.com']],
        optional: false
      }
    ],

    authorization: {
      type: 'oauth2',

      authorization_url: lambda do |connection|
        "#{connection['environment']}/oauth/authorize?client_id=" \
        "#{connection['client_id']}&response_type=code" \
        '&redirect_uri=https://www.workato.com/oauth/callback'
      end,

      acquire: lambda do |connection, auth_code, redirect_uri|
        post("#{connection['environment']}/oauth/token").
          payload(client_id: connection['client_id'],
                  client_secret: connection['client_secret'],
                  grant_type: 'authorization_code',
                  code: auth_code,
                  redirect_uri: redirect_uri)
      end,

      refresh: lambda do |connection, refresh_token|
        post("#{connection['environment']}/oauth/token").
          payload(client_id: connection['client_id'],
                  client_secret: connection['client_secret'],
                  grant_type: 'refresh_token',
                  refresh_token: refresh_token)
      end,

      refresh_on: [401],

      detect_on: [401],

      apply: lambda do |_connection, access_token|
        headers('Authorization' => "Bearer #{access_token}")
      end
    },

    base_uri: lambda do |connection|
      "#{connection['environment']}/v1/"
    end
  },

  test: lambda do |_connection|
    get('me')
  end,

  methods: {
    make_schema_builder_fields_sticky: lambda do |schema|
      schema.map do |field|
        if field['properties'].present?
          field['properties'] = call('make_schema_builder_fields_sticky',
                                     field['properties'])
        end
        field['sticky'] = true

        field
      end
    end,
    format_schema: lambda do |input|
      input&.map do |field|
        if (props = field[:properties])
          field[:properties] = call('format_schema', props)
        elsif (props = field['properties'])
          field['properties'] = call('format_schema', props)
        end
        if (name = field[:name])
          field[:label] = field[:label].presence || name.labelize
          field[:name] = name.
                           gsub(/\W/) { |spl_chr| "__#{spl_chr.encode_hex}__" }
        elsif (name = field['name'])
          field['label'] = field['label'].presence || name.labelize
          field['name'] = name.
                            gsub(/\W/) { |spl_chr| "__#{spl_chr.encode_hex}__" }
        end

        field
      end
    end,
    format_payload: lambda do |payload|
      if payload.is_a?(Array)
        payload.map do |array_value|
          call('format_payload', array_value)
        end
      elsif payload.is_a?(Hash)
        payload.each_with_object({}) do |(key, value), hash|
          key = key.gsub(/__\w+__/) do |string|
            string.gsub(/__/, '').decode_hex.as_utf8
          end
          if value.is_a?(Array) || value.is_a?(Hash)
            value = call('format_payload', value)
          end
          hash[key] = value
        end
      end
    end,
    format_response: lambda do |response|
      response = response&.compact unless response.is_a?(String) || response
      if response.is_a?(Array)
        response.map do |array_value|
          call('format_response', array_value)
        end
      elsif response.is_a?(Hash)
        response.each_with_object({}) do |(key, value), hash|
          key = key.gsub(/\W/) { |spl_chr| "__#{spl_chr.encode_hex}__" }
          if value.is_a?(Array) || value.is_a?(Hash)
            value = call('format_response', value)
          end
          hash[key] = value
        end
      else
        response
      end
    end,
    get_url: lambda do |input|
      case input['object']
      when 'company_location'
        "companies/#{input.delete('company_id')}/locations"
      when 'company_contractor'
        "companies/#{input.delete('company_id')}/contractors"
      when 'company_employee'
        "companies/#{input.delete('company_id')}/employees"
      when 'time_off_request'
        "companies/#{input.delete('company_id')}/time_off_requests"
      when 'pay_roll'
        "companies/#{input.delete('company_id')}/payrolls"
      when 'pay_schedule'
        "companies/#{input.delete('company_id')}/pay_schedules"
      when 'pay_period'
        "companies/#{input.delete('company_id')}/pay_periods"
      when 'employee_home_address'
        "employees/#{input.delete('employee_id')}/home_address"
      when 'employee_job'
        "employees/#{input.delete('employee_id')}/jobs"
      when 'employee_termination'
        "employees/#{input.delete('employee_id')}/terminations"
      when 'employee_employee_benefit'
        "employees/#{input.delete('employee_id')}/employee_benefits"
      when 'company_company_benefit'
        "companies/#{input.delete('company_id')}/company_benefits"
      else
        input['object'].pluralize
      end
    end,
    employee_schema: lambda do
      [
        { name: 'id', label: 'Employee ID',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'uuid', label: 'UUID' },
        { name: 'version',
          hint: 'The version of the object in the Gusto system.' },
        { name: 'company_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'first_name', sticky: true },
        { name: 'middle_initial', sticky: true },
        { name: 'last_name', sticky: true },
        { name: 'company_uuid', label: 'Company UUID' },
        { name: 'manager_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'manager_uuid', label: 'Manager UUID' },
        { name: 'department' },
        { name: 'email', sticky: true },
        { name: 'ssn', label: 'SSN', sticky: true },
        { name: 'has_ssn', label: 'Has SSN',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          hint: 'Indicates whether the employee has an SSN in Gusto.',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'has_ssn',
            type: 'boolean',
            label: 'Has SSN',
            optional: true,
            control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'phone' },
        { name: 'preferred_first_name' },
        { name: 'work_email' },
        { name: 'current_employment_status' },
        { name: 'date_of_birth', type: 'date', sticky: true },
        { name: 'terminated',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'two_percent_shareholder',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          hint: 'Whether the employee is a two percent shareholder ' \
          'of an S-Corp for tax purposes.',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'two_percent_shareholder',
            type: 'boolean',
            label: 'Two percent shareholder',
            optional: true,
            control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'jobs', type: 'array', of: 'object',
          properties: call('job_schema') },
        { name: 'eligible_paid_time_off', type: 'array', of: 'object',
          properties: [
            { name: 'name' },
            { name: 'accrual_unit' },
            { name: 'accrual_period' },
            { name: 'accrual_rate' },
            { name: 'accrual_balance' },
            { name: 'maximum_accrual_balance' },
            { name: 'paid_at_termination',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' }
          ] },
        { name: 'terminations', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'employee_id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'version' },
            { name: 'active',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' },
            { name: 'effective_date', type: 'date' },
            { name: 'run_termination_payroll',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' }
          ] },
        { name: 'home_address', type: 'object',
          properties: call('employee_home_address_schema') },
        { name: 'garnishments', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'version' },
            { name: 'employee_id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'active',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' },
            { name: 'amount' },
            { name: 'description' },
            { name: 'court_ordered',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' },
            { name: 'times',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'recurring',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' },
            { name: 'annual_maximum' },
            { name: 'pay_period_maximum' },
            { name: 'deduct_as_percentage',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' }
          ] },
        { name: 'onboarded',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'custom_fields', type: 'array', of: 'object',
          properties: [
            { name: 'id', optional: false },
            { name: 'company_custom_field_id', optional: false },
            { name: 'name', optional: false },
            { name: 'type', control_type: 'select',
              optional: false,
              pick_list: 'custom_field_type_list',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'type', label: 'Type',
                optional: false,
                type: 'string', control_type: 'text',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are <b>text</b>, <b>currency</b>, ' \
                      '<b>number</b>, <b>date</b>, <b>radio</b>.'
              } },
            { name: 'description' },
            { name: 'value', optional: false },
            { name: 'selection_options', type: 'array', of: 'string',
              hint: 'An array of options for fields of type radio. ' \
                    'Otherwise, null.' }
          ] }
      ]
    end,
    company_employee_schema: lambda do
      call('employee_schema')
    end,
    company_employee_create_schema: lambda do
      [
        { name: 'company_id', label: 'Company ID or UUID',
          optional: false,
          hint: 'The ID or UUID of the company' }
      ].concat(
        call('employee_schema').
          only('email', 'first_name', 'last_name',
               'middle_initial', 'date_of_birth', 'ssn').
          required('first_name', 'last_name')
      )
    end,
    employee_update_schema: lambda do
      call('employee_schema').
        only('id', 'email', 'first_name', 'last_name', 'middle_initial',
             'date_of_birth', 'ssn', 'two_percent_shareholder', 'version').
        required('id', 'version')
    end,
    employee_home_address_schema: lambda do
      [
        { name: 'id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'version',
          hint: 'The version of the object in the Gusto system.' },
        { name: 'company_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'employee_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'phone_number' },
        { name: 'street_1' },
        { name: 'street_2' },
        { name: 'city' },
        { name: 'state' },
        { name: 'zip' },
        { name: 'country' },
        { name: 'active',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'mailing_address',
          type: 'boolean',
          control_type: 'checkbox',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          render_input: 'boolean_conversion',
          toggle_field: {
            name: 'mailing_address',
            label: 'Mailing address',
            type: 'string',
            control_type: 'text',
            optional: true,
            parse_output: 'boolean_conversion',
            render_input: 'boolean_conversion',
            hint: 'Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } },
        { name: 'filing_address',
          type: 'boolean',
          control_type: 'checkbox',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          render_input: 'boolean_conversion',
          toggle_field: {
            name: 'filing_address',
            label: 'Filing address',
            type: 'string',
            control_type: 'text',
            optional: true,
            sticky: true,
            parse_output: 'boolean_conversion',
            render_input: 'boolean_conversion',
            hint: 'Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } }
      ]
    end,
    employee_home_address_update_schema: lambda do
      call('employee_home_address_schema').
        ignored('id', 'active').
        required('employee_id', 'street_1', 'city', 'state', 'zip')
    end,
    company_contractor_schema: lambda do
      [
        { name: 'records', label: 'Company contractors',
          type: 'array', of: 'object',
          properties: call('contractor_schema') }
      ]
    end,
    company_contractor_create_schema: lambda do
      call('contractor_schema').
        ignored('id', 'version', 'is_active', 'address',
                'type', 'wage_type').required('start_date', 'company_id').
        concat(
          [
            { name: 'type', type: 'string', control_type: 'select',
              optional: false,
              pick_list: [
                %w[Individual Individual],
                %w[Business Business]
              ],
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'type',
                label: 'Type',
                type: 'string', control_type: 'text',
                optional: false,
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are Individual, Business.'
              } },
            { name: 'self_onboarding',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion',
              hint: 'Specifies whether the contractor or the administrator ' \
              'will complete onboarding in. If self_onboarding is true, ' \
              'then email is required.',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'self_onboarding',
                type: 'boolean',
                label: 'Self onboarding',
                optional: true,
                control_type: 'text',
                render_input: 'boolean_conversion',
                parse_output: 'boolean_conversion',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are true or false'
              } },
            { name: 'wage_type', type: 'string', control_type: 'select',
              optional: false,
              pick_list: [
                %w[Fixed Fixed],
                %w[Hourly Hourly]
              ],
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'wage_type',
                label: 'Wage type',
                type: 'string', control_type: 'text',
                optional: false,
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are Fixed, Hourly.'
              } }
          ]
        )
    end,
    contractor_schema: lambda do
      [
        { name: 'id', label: 'Contractor ID',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'company_id', label: 'Company ID or UUID',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'wage_type', type: 'string', control_type: 'select',
          pick_list: [
            %w[Fixed Fixed],
            %w[Hourly Hourly]
          ],
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'wage_type',
            label: 'Wage type',
            type: 'string', control_type: 'text',
            optional: true,
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are Fixed, Hourly.'
          } },
        { name: 'is_active',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'version',
          hint: 'The version of the object in the Gusto system.' },
        { name: 'start_date', type: 'date' },
        { name: 'type', type: 'string', control_type: 'select',
          pick_list: [
            %w[Individual Individual],
            %w[Business Business]
          ],
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'type',
            label: 'Type',
            type: 'string', control_type: 'text',
            optional: true,
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are Individual, Business.'
          } },
        { name: 'first_name', sticky: true,
          hint: 'The contractor’s first name. '\
          'Required for “Individual” contractors' },
        { name: 'last_name', sticky: true,
          hint: 'The contractor’s last name. '\
          'Required for “Individual” contractors' },
        { name: 'middle_initial' },
        { name: 'business_name', sticky: true,
          hint: 'The name of the contractor business. ' \
          'Required for "Business" contractors' },
        { name: 'ein', label: 'EIN',
          hint: 'The employer identification number for this company.' },
        { name: 'email' },
        { name: 'address', type: 'object',
          properties: [
            { name: 'street_1' },
            { name: 'street_2' },
            { name: 'city' },
            { name: 'state' },
            { name: 'zip' },
            { name: 'country' }
          ] },
        { name: 'hourly_rate',
          hint: 'The contractor’s hourly rate. ' \
          'Required if the <b>Wage type</b> is "Hourly".' }
      ]
    end,
    contractor_update_schema: lambda do
      call('contractor_schema').
        ignored('company_id', 'is_active', 'address', 'email').required('id')
    end,
    employee_job_schema: lambda do
      [
        { name: 'records', label: 'Employee jobs',
          type: 'array', of: 'object',
          properties: call('job_schema') }
      ]
    end,
    employee_job_create_schema: lambda do
      call('job_schema').only('title', 'hire_date', 'location_id',
                              'employee_id').
        required('employee_id')
    end,
    job_schema: lambda do
      [
        { name: 'id', label: 'Job ID',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'uuid', label: 'UUID' },
        { name: 'version',
          hint: 'The version of the object in the Gusto system.' },
        { name: 'employee_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'employee_uuid', label: 'Employee UUID' },
        { name: 'location_id',
          type: 'integer', control_type: 'integer',
          hint: "Id of job's work location.",
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'location', type: 'object',
          properties: call('location_schema').
                        ignored('version', 'company_id', 'active').
                        concat(
                          [
                            { name: 'inactive', type: 'boolean',
                              control_type: 'checkbox',
                              parse_output: 'boolean_conversion' }
                          ]
                        ) },
        { name: 'hire_date', type: 'date', sticky: true },
        { name: 'title', sticky: true },
        { name: 'primary',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'rate', type: 'integer' },
        { name: 'payment_unit' },
        { name: 'current_compensation_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'current_compensation_uuid',
          label: 'Current compensation UUID' },
        { name: 'two_percent_shareholder', type: 'boolean',
          control_type: 'checkbox',
          parse_output: 'boolean_conversion' },
        { name: 'compensations', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'uuid', label: 'UUID' },
            { name: 'version' },
            { name: 'job_id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'job_uuid', label: 'Job UUID' },
            { name: 'rate', type: 'integer' },
            { name: 'payment_unit' },
            { name: 'flsa_status', label: 'FLSA status' },
            { name: 'effective_date', type: 'date' }
          ] }
      ]
    end,
    job_update_schema: lambda do
      call('job_schema').only('id', 'version', 'title',
                              'hire_date', 'location_id').
        required('id', 'version')
    end,
    time_off_request_schema: lambda do
      [
        { name: 'id' },
        { name: 'uuid', label: 'UUID' },
        { name: 'status' },
        { name: 'employee_note' },
        { name: 'employer_note' },
        { name: 'days', type: 'array', of: 'object',
          properties: [
            { name: 'day' },
            { name: 'hours' }
          ] },
        { name: 'request_type' },
        { name: 'employee', type: 'object',
          properties: [
            { name: 'id' },
            { name: 'full_name' }
          ] },
        { name: 'approver', type: 'object',
          properties: [
            { name: 'id' },
            { name: 'full_name' }
          ] },
        { name: 'initiator', type: 'object',
          properties: [
            { name: 'id' },
            { name: 'full_name' }
          ] }
      ]
    end,
    pay_roll_schema: lambda do |input|
      array = input['include']&.split(',')
      [
        { name: 'payroll_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'payroll_uuid', label: 'Payroll UUID' },
        { name: 'version' },
        { name: 'payroll_deadline' },
        { name: 'check_date', type: 'date', control_type: 'date' },
        { name: 'processed',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'processed_date', type: 'date', control_type: 'date' },
        { name: 'calculated_at', type: 'date_time', control_type: 'date_time' },
        { name: 'company_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'pay_period', type: 'object',
          properties: [
            { name: 'start_date', type: 'date' },
            { name: 'end_date', type: 'date' },
            { name: 'pay_schedule_id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'pay_schedule_uuid', label: 'Pay schedule UUID' }
          ] },
        { name: 'totals', type: 'object',
          properties: [
            { name: 'company_debit' },
            { name: 'net_pay_debit' },
            { name: 'tax_debit' },
            { name: 'reimbursement_debit' },
            { name: 'child_support_debit' },
            { name: 'reimbursements' },
            { name: 'net_pay' },
            { name: 'gross_pay' },
            { name: 'employee_bonuses' },
            { name: 'employee_commissions' },
            { name: 'employee_cash_tips' },
            { name: 'employee_paycheck_tips' },
            { name: 'additional_earnings' },
            { name: 'owners_draw' },
            { name: 'check_amount' },
            { name: 'employer_taxes' },
            { name: 'employee_taxes' },
            { name: 'benefits' },
            { name: 'employee_benefits_deductions' },
            { name: 'deferred_payroll_taxes' }
          ] },
        { name: 'employee_compensations', type: 'array', of: 'object',
          properties: [
            { name: 'employee_id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'excluded', sticky: true,
              type: 'boolean',
              control_type: 'checkbox',
              parse_output: 'boolean_conversion',
              toggle_hint: 'Select from list',
              render_input: 'boolean_conversion',
              hint: 'This employee will be excluded from payroll ' \
                    'calculation and will not be paid for the payroll.',
              toggle_field: { name: 'excluded',
                              label: 'Excluded',
                              type: 'string',
                              control_type: 'text',
                              optional: true,
                              sticky: true,
                              parse_output: 'boolean_conversion',
                              render_input: 'boolean_conversion',
                              hint: 'Accepted values are true or false',
                              toggle_hint: 'Use custom value' } },
            { name: 'gross_pay' },
            { name: 'net_pay' },
            { name: 'payment_method' },
            { name: 'fixed_compensations', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'amount' },
                { name: 'job_id',
                  type: 'integer', control_type: 'integer',
                  render_input: 'integer_conversion',
                  parse_output: 'integer_conversion' }
              ] },
            { name: 'hourly_compensations', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'hours' },
                { name: 'job_id',
                  type: 'integer', control_type: 'integer',
                  render_input: 'integer_conversion',
                  parse_output: 'integer_conversion' },
                { name: 'compensation_multiplier',
                  type: 'integer', control_type: 'integer',
                  render_input: 'integer_conversion',
                  parse_output: 'integer_conversion' }
              ] },
            { name: 'paid_time_off', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'hours' }
              ] }
          ].concat(call('pay_roll_include_schema').
                     only(array&.dig(0), array&.dig(1), array&.dig(2))) }
      ]
    end,
    pay_roll_include_schema: lambda do
      [
        { name: 'benefits', type: 'array', of: 'object',
          properties: [
            { name: 'name' },
            { name: 'employee_deduction' },
            { name: 'company_contribution' },
            { name: 'imputed',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' }
          ] },
        { name: 'deductions', type: 'array', of: 'object',
          properties: [
            { name: 'name' },
            { name: 'amount' }
          ] },
        { name: 'taxes', type: 'array', of: 'object',
          properties: [
            { name: 'name' },
            { name: 'employer',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' },
            { name: 'amount' }
          ] }
      ]
    end,
    pay_roll_update_schema: lambda do
      [
        { name: 'company_id', optional: false },
        { name: 'start_date', type: 'date', optional: false },
        { name: 'end_date', type: 'date', optional: false },
        { name: 'version', optional: false,
          hint: 'The version of the object in the Gusto system.' },
        { name: 'employee_compensations', type: 'array', of: 'object',
          optional: false, sticky: true,
          properties: [
            { name: 'employee_id', optional: false,
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'excluded', sticky: true,
              type: 'boolean',
              control_type: 'checkbox',
              parse_output: 'boolean_conversion',
              toggle_hint: 'Select from list',
              render_input: 'boolean_conversion',
              hint: 'This employee will be excluded from payroll ' \
                    'calculation and will not be paid for the payroll.',
              toggle_field: { name: 'excluded',
                              label: 'Excluded',
                              type: 'string',
                              control_type: 'text',
                              optional: true,
                              sticky: true,
                              parse_output: 'boolean_conversion',
                              render_input: 'boolean_conversion',
                              hint: 'Accepted values are true or false',
                              toggle_hint: 'Use custom value' } },
            { name: 'fixed_compensations', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'amount' },
                { name: 'job_id',
                  type: 'integer', control_type: 'integer',
                  render_input: 'integer_conversion',
                  parse_output: 'integer_conversion' }
              ] },
            { name: 'hourly_compensations', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'hours' },
                { name: 'job_id',
                  type: 'integer', control_type: 'integer',
                  render_input: 'integer_conversion',
                  parse_output: 'integer_conversion' }
              ] },
            { name: 'paid_time_off', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'hours' }
              ] }
          ] }
      ]
    end,
    pay_schedule_schema: lambda do
      [
        { name: 'id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'uuid', label: 'UUID' },
        { name: 'frequency' },
        { name: 'anchor_pay_date', type: 'date' },
        { name: 'day_1',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'day_2',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'name' },
        { name: 'auto_pilot' }
      ]
    end,
    pay_period_schema: lambda do
      [
        { name: 'start_date', type: 'date' },
        { name: 'end_date', type: 'date' },
        { name: 'pay_schedule_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'pay_schedule_uuid', label: 'Pay schedule UUID' },
        { name: 'payroll', type: 'object',
          properties: [
            { name: 'payroll_deadline' },
            { name: 'processed',
              type: 'boolean', control_type: 'checkbox',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion' }
          ] },
        { name: 'eligible_employees', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              parse_output: 'integer_conversion' },
            { name: 'uuid', label: 'UUID' },
            { name: 'job_ids', type: 'array', of: 'integer',
              label: 'Job IDs' },
            { name: 'job_uuids', type: 'array', of: 'string',
              label: 'Job UUIDs' }
          ] }
      ]
    end,
    company_schema: lambda do
      [
        { name: 'id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'uuid', label: 'UUID' },
        { name: 'name' },
        { name: 'trade_name' },
        { name: 'ein', label: 'EIN',
          hint: 'The employer identification number for this company.' },
        { name: 'entity_type' },
        { name: 'tier' },
        { name: 'is_suspended', type: 'boolean', control_type: 'checkbox',
          parse_output: 'boolean_conversion' },
        { name: 'company_status' },
        { name: 'locations', type: 'array', of: 'object',
          properties: call('location_schema').
                        ignored('version', 'company_id', 'phone_number', 'country') },
        { name: 'compensations', type: 'object',
          properties: [
            { name: 'hourly', type: 'array', of: 'object',
              properties: [
                { name: 'name' },
                { name: 'multiple',
                  type: 'integer', control_type: 'integer',
                  render_input: 'integer_conversion',
                  parse_output: 'integer_conversion' }
              ] },
            { name: 'fixed', type: 'array', of: 'object',
              properties: [
                { name: 'name' }
              ] },
            { name: 'paid_time_off', type: 'array', of: 'object',
              properties: [
                { name: 'name' }
              ] }
          ] },
        { name: 'primary_signatory', type: 'object',
          properties: [
            { name: 'uuid', label: 'UUID' },
            { name: 'first_name' },
            { name: 'middle_initial' },
            { name: 'last_name' },
            { name: 'phone' },
            { name: 'email' },
            { name: 'home_address', type: 'object',
              properties: call('employee_home_address_schema').
                            ignored('id', 'employee_id', 'version') }
          ] },
        { name: 'primary_payroll_admin', type: 'object',
          properties: [
            { name: 'first_name' },
            { name: 'last_name' },
            { name: 'phone' },
            { name: 'email' }
          ] }
      ]
    end,
    company_location_schema: lambda do
      [
        { name: 'records', label: 'Company locations',
          type: 'array', of: 'object',
          properties: call('location_schema') }
      ]
    end,
    location_schema: lambda do
      [
        { name: 'id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'version' },
        { name: 'company_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'phone_number' },
        { name: 'street_1' },
        { name: 'street_2' },
        { name: 'city' },
        { name: 'state' },
        { name: 'zip' },
        { name: 'country' },
        { name: 'active',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' }
      ]
    end,
    company_location_create_schema: lambda do
      [
        { name: 'company_id', optional: false }
      ].concat(call('location_update_schema').ignored('id', 'version').
      required('phone_number', 'street_1', 'street_2', 'city', 'state', 'zip'))
    end,
    location_update_schema: lambda do
      [
        { name: 'id', label: 'Location ID',
          optional: false,
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'version',
          hint: 'The version of the object in the Gusto system.' },
        { name: 'phone_number' },
        { name: 'street_1' },
        { name: 'street_2' },
        { name: 'city' },
        { name: 'state', hint: 'Short form of state. e.g. CA' },
        { name: 'zip' },
        { name: 'country' },
        { name: 'mailing_address',
          type: 'boolean',
          control_type: 'checkbox',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          render_input: 'boolean_conversion',
          toggle_field: {
            name: 'mailing_address',
            label: 'Mailing address',
            type: 'string',
            control_type: 'text',
            optional: true,
            parse_output: 'boolean_conversion',
            render_input: 'boolean_conversion',
            hint: 'Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } },
        { name: 'filing_address',
          type: 'boolean',
          control_type: 'checkbox',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          render_input: 'boolean_conversion',
          toggle_field: {
            name: 'filing_address',
            label: 'Filing address',
            type: 'string',
            control_type: 'text',
            optional: true,
            sticky: true,
            parse_output: 'boolean_conversion',
            render_input: 'boolean_conversion',
            hint: 'Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } }
      ]
    end,
    employee_termination_schema: lambda do
      [
        { name: 'id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'version',
          hint: 'The version of the object in the Gusto system.' },
        { name: 'employee_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'active',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion' },
        { name: 'effective_date', type: 'date', sticky: true },
        { name: 'run_termination_payroll', sticky: true,
          type: 'boolean', control_type: 'checkbox',
          hint: 'If Yes, the employee should recieve their final wages via ' \
                'an offcycle payroll. If No, they should receive their ' \
                'final wages on their current pay schedule.',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'run_termination_payroll',
            type: 'boolean',
            label: 'Run termination payroll',
            optional: true,
            control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } }
      ]
    end,
    termination_schema: lambda do
      call('employee_termination_schema')
    end,
    employee_termination_create_schema: lambda do
      call('employee_termination_schema').
        only('effective_date', 'run_termination_payroll', 'employee_id').
        required('effective_date', 'employee_id')
    end,
    termination_update_schema: lambda do
      call('employee_termination_schema').required('id', 'version').
        only('effective_date', 'run_termination_payroll', 'version', 'id')
    end,
    employee_employee_benefit_schema: lambda do
      call('employee_benefit_schema')
    end,
    employee_benefit_schema: lambda do
      [
        { name: 'id', label: 'Employee benefit ID',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'version' },
        { name: 'employee_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'company_benefit_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'active',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'active', label: 'Active',
            type: 'boolean', control_type: 'text',
            optional: true,
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'employee_deduction' },
        { name: 'company_contribution' },
        { name: 'employee_deduction_annual_maximum' },
        { name: 'company_contribution_annual_maximum' },
        { name: 'limit_option' },
        { name: 'deduct_as_percentage',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'deduct_as_percentage', type: 'boolean',
            label: 'Deduct as percentage',
            optional: true, control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'contribute_as_percentage',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'contribute_as_percentage',
            type: 'boolean', label: 'Contribute as percentage',
            optional: true, control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'catch_up',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'catch_up', type: 'boolean',
            label: 'Catch up', optional: true,
            control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'coverage_amount' },
        { name: 'deduction_reduces_taxable_income', sticky: true,
          control_type: 'select',
          pick_list: %w[unset reduces_taxable_income reduces_taxable_income].
                       map { |e| [e.labelize, e] },
          hint: 'Whether the employee deduction reduces taxable income or ' \
                'not. Only valid for Group Term Life benefits. Note: when ' \
                'the value is not "unset", coverage amount and coverage ' \
                'salary multiplier are ignored.',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'deduction_reduces_taxable_income',
            label: 'Deduction reduces taxable income',
            optional: true, sticky: true,
            type: 'string', control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Whether the employee deduction reduces taxable income or ' \
                  'not. Only valid for Group Term Life benefits. Note: when ' \
                  'the value is not "unset", coverage amount and coverage ' \
                  'salary multiplier are ignored.'
          } },
        { name: 'coverage_salary_multiplier' },
        { name: 'elective',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'elective', type: 'boolean',
            label: 'Elective', optional: true,
            control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'contribution', type: 'object',
          properties: [
            { name: 'type', control_type: 'select',
              sticky: true,
              pick_list: 'contribution_type_list',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'type', label: 'Type',
                optional: true, sticky: true,
                type: 'string', control_type: 'text',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are <b>amount, percentage, tiered</b>'
              } },
            { name: 'value' }
          ] }
      ]
    end,
    employee_employee_benefit_create_schema: lambda do
      call('employee_benefit_schema').
        ignored('id', 'version').required('employee_id', 'company_benefit_id')
    end,
    employee_benefit_update_schema: lambda do
      call('employee_benefit_schema').required('id', 'version')
    end,
    company_company_benefit_schema: lambda do
      call('company_benefit_schema')
    end,
    company_benefit_schema: lambda do
      [
        { name: 'id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'version' },
        { name: 'benefit_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'company_id',
          type: 'integer', control_type: 'integer',
          render_input: 'integer_conversion',
          parse_output: 'integer_conversion' },
        { name: 'active',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'active', label: 'Active',
            type: 'boolean', control_type: 'text',
            optional: true,
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'description' },
        { name: 'supports_percentage_amounts',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'supports_percentage_amounts', type: 'boolean',
            label: 'Supports percentage amounts',
            optional: true, control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'responsible_for_employer_taxes',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'responsible_for_employer_taxes',
            type: 'boolean', label: 'Responsible for employer taxes',
            optional: true, control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } },
        { name: 'responsible_for_employee_w2',
          label: 'Responsible for employee w2',
          type: 'boolean', control_type: 'checkbox',
          render_input: 'boolean_conversion',
          parse_output: 'boolean_conversion',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'responsible_for_employee_w2', type: 'boolean',
            label: 'Responsible for employee w2', optional: true,
            control_type: 'text',
            render_input: 'boolean_conversion',
            parse_output: 'boolean_conversion',
            toggle_hint: 'Use custom value',
            hint: 'Allowed values are true or false'
          } }
      ]
    end,
    company_company_benefit_create_schema: lambda do
      call('company_benefit_schema').
        ignored('id', 'version', 'supports_percentage_amounts').
        required('company_id', 'benefit_id', 'description')
    end,
    company_benefit_update_schema: lambda do
      call('company_benefit_schema').required('id', 'version')
    end,
    benefit_schema: lambda do
      [
        { name: 'id', type: 'integer' },
        { name: 'name' },
        { name: 'description' },
        { name: 'pretax', type: 'boolean' },
        { name: 'posttax', type: 'boolean' },
        { name: 'imputed', type: 'boolean' },
        { name: 'healthcare', type: 'boolean' },
        { name: 'retirement', type: 'boolean' },
        { name: 'yearly_limit', type: 'boolean' }
      ]
    end
  },

  object_definitions: {
    custom_action_input: {
      fields: lambda do |connection, config_fields|
        verb = config_fields['verb']
        input_schema = parse_json(config_fields.dig('input', 'schema') || '[]')
        data_props =
          input_schema.map do |field|
            if config_fields['request_type'] == 'multipart' &&
               field['binary_content'] == 'true'
              field['type'] = 'object'
              field['properties'] = [
                { name: 'file_content', optional: false },
                {
                  name: 'content_type',
                  default: 'text/plain',
                  sticky: true
                },
                { name: 'original_filename', sticky: true }
              ]
            end
            field
          end
        data_props = call('make_schema_builder_fields_sticky', data_props)
        input_data =
          if input_schema.present?
            if input_schema.dig(0, 'type') == 'array' &&
               input_schema.dig(0, 'details', 'fake_array')
              {
                name: 'data',
                type: 'array',
                of: 'object',
                properties: data_props.dig(0, 'properties')
              }
            else
              { name: 'data', type: 'object', properties: data_props }
            end
          end

        [
          {
            name: 'path',
            hint: 'Base URI is <b>' \
            "#{connection['environment']}/v1/" \
            '</b> - path will be appended to this URI. Use absolute URI to ' \
            'override this base URI.',
            optional: false
          },
          if %w[post put patch].include?(verb)
            {
              name: 'request_type',
              default: 'json',
              sticky: true,
              extends_schema: true,
              control_type: 'select',
              pick_list: [
                ['JSON request body', 'json'],
                ['URL encoded form', 'url_encoded_form'],
                ['Mutipart form', 'multipart'],
                ['Raw request body', 'raw']
              ]
            }
          end,
          {
            name: 'response_type',
            default: 'json',
            sticky: false,
            extends_schema: true,
            control_type: 'select',
            pick_list: [['JSON response', 'json'], ['Raw response', 'raw']]
          },
          if %w[get options delete].include?(verb)
            {
              name: 'input',
              label: 'Request URL parameters',
              sticky: true,
              add_field_label: 'Add URL parameter',
              control_type: 'form-schema-builder',
              type: 'object',
              properties: [
                {
                  name: 'schema',
                  sticky: input_schema.blank?,
                  extends_schema: true
                },
                input_data
              ].compact
            }
          else
            {
              name: 'input',
              label: 'Request body parameters',
              sticky: true,
              type: 'object',
              properties:
                if config_fields['request_type'] == 'raw'
                  [{
                    name: 'data',
                    sticky: true,
                    control_type: 'text-area',
                    type: 'string'
                  }]
                else
                  [
                    {
                      name: 'schema',
                      sticky: input_schema.blank?,
                      extends_schema: true,
                      schema_neutral: true,
                      control_type: 'schema-designer',
                      sample_data_type: 'json_input',
                      custom_properties:
                        if config_fields['request_type'] == 'multipart'
                          [{
                            name: 'binary_content',
                            label: 'File attachment',
                            default: false,
                            optional: true,
                            sticky: true,
                            render_input: 'boolean_conversion',
                            parse_output: 'boolean_conversion',
                            control_type: 'checkbox',
                            type: 'boolean'
                          }]
                        end
                    },
                    input_data
                  ].compact
                end
            }
          end,
          {
            name: 'request_headers',
            sticky: false,
            extends_schema: true,
            control_type: 'key_value',
            empty_list_title: 'Does this HTTP request require headers?',
            empty_list_text: 'Refer to the API documentation and add ' \
            'required headers to this HTTP request',
            item_label: 'Header',
            type: 'array',
            of: 'object',
            properties: [{ name: 'key' }, { name: 'value' }]
          },
          unless config_fields['response_type'] == 'raw'
            {
              name: 'output',
              label: 'Response body',
              sticky: true,
              extends_schema: true,
              schema_neutral: true,
              control_type: 'schema-designer',
              sample_data_type: 'json_input'
            }
          end,
          {
            name: 'response_headers',
            sticky: false,
            extends_schema: true,
            schema_neutral: true,
            control_type: 'schema-designer',
            sample_data_type: 'json_input'
          }
        ].compact
      end
    },
    custom_action_output: {
      fields: lambda do |_connection, config_fields|
        response_body = { name: 'body' }

        [
          if config_fields['response_type'] == 'raw'
            response_body
          elsif (output = config_fields['output'])
            output_schema = call('format_schema', parse_json(output))
            if output_schema.dig(0, 'type') == 'array' &&
               output_schema.dig(0, 'details', 'fake_array')
              response_body[:type] = 'array'
              response_body[:properties] = output_schema.dig(0, 'properties')
            else
              response_body[:type] = 'object'
              response_body[:properties] = output_schema
            end

            response_body
          end,
          if (headers = config_fields['response_headers'])
            header_props = parse_json(headers)&.map do |field|
              if field[:name].present?
                field[:name] = field[:name].gsub(/\W/, '_').downcase
              elsif field['name'].present?
                field['name'] = field['name'].gsub(/\W/, '_').downcase
              end
              field
            end

            { name: 'headers', type: 'object', properties: header_props }
          end
        ].compact
      end
    },
    search_object_input: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        case config_fields['object']
        when 'employee'
          [
            { name: 'terminated', sticky: 'true',
              type: 'boolean', control_type: 'checkbox',
              hint: 'Returns all employees that have not been ' \
                    'terminated if left blank.',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'terminated',
                type: 'boolean',
                label: 'Terminated',
                optional: true,
                control_type: 'text',
                render_input: 'boolean_conversion',
                parse_output: 'boolean_conversion',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are true or false'
              } }
          ]
        when 'company_employee'
          [
            { name: 'company_id', optional: false,
              extends_schema: true },
            { name: 'terminated', sticky: 'true',
              type: 'boolean', control_type: 'checkbox',
              hint: 'false: returns all employees that have ' \
                    'not been terminated.',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'terminated',
                type: 'boolean',
                label: 'Terminated',
                optional: true,
                control_type: 'text',
                render_input: 'boolean_conversion',
                parse_output: 'boolean_conversion',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are true or false'
              } },
            { name: 'include', sticky: true,
              type: 'array', of: 'string',
              hint: 'Include the requested attribute(s) in each employee ' \
                    "response. e.g ['custom_fields']" },
            { name: 'per', label: 'Limit', type: 'integer',
              control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'Number of employees per page. ' \
                    'When unspecified, will default to 25' },
            { name: 'page', type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'The page that is requested. When unspecified, ' \
                    'will load all employees.' }
          ]
        when 'time_off_request'
          [
            { name: 'company_id', optional: false,
              extends_schema: true },
            { name: 'start_date', type: 'date', sticky: 'true' },
            { name: 'end_date', type: 'date', sticky: 'true' },
            { name: 'per', label: 'Limit', type: 'integer',
              control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'Number of employees per page. ' \
                    'When unspecified, will default to 25' },
            { name: 'page', type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'The page that is requested. When unspecified, ' \
                    'will load all employees.' }
          ]
        when 'pay_period'
          [
            { name: 'company_id', optional: false,
              extends_schema: true },
            { name: 'start_date', type: 'date', sticky: 'true' },
            { name: 'end_date', type: 'date', sticky: 'true' }
          ]
        when 'pay_roll'
          [
            { name: 'company_id', optional: false,
              extends_schema: true },
            { name: 'start_date', type: 'date', sticky: 'true' },
            { name: 'end_date', type: 'date', sticky: 'true' },
            { name: 'processed', sticky: 'true',
              type: 'boolean', control_type: 'checkbox',
              hint: 'Returns all payrolls that have not yet been ' \
                    'processed if left blank',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'processed',
                type: 'boolean',
                label: 'Processed',
                optional: true,
                control_type: 'text',
                render_input: 'boolean_conversion',
                parse_output: 'boolean_conversion',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are true or false'
              } },
            { name: 'include_off_cycle', sticky: 'true',
              type: 'boolean', control_type: 'checkbox',
              hint: 'Returns both regular and off-cycle payrolls ' \
                    'if set to Yes.',
              render_input: 'boolean_conversion',
              parse_output: 'boolean_conversion',
              toggle_hint: 'Select from list',
              toggle_field: {
                name: 'include_off_cycle',
                type: 'boolean',
                label: 'Include off cycle',
                optional: true,
                control_type: 'text',
                render_input: 'boolean_conversion',
                parse_output: 'boolean_conversion',
                toggle_hint: 'Use custom value',
                hint: 'Allowed values are true or false'
              } },
            { name: 'include', sticky: 'true',
              control_type: 'multiselect', delimiter: ',',
              extends_schema: true,
              pick_list: [
                %w[Benefits benefits],
                %w[Deductions deductions],
                %w[Taxes taxes]
              ],
              hint: 'Returns payrolls and includes benefits, deductions, ' \
              'and taxes in employee_compensation. You can choose to ' \
              'include only what you need.' }
          ]
        when 'pay_schedule'
          [
            { name: 'company_id', optional: false,
              extends_schema: true },
            { name: 'per', label: 'Limit', type: 'integer',
              control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'Number of employees per page. ' \
                    'When unspecified, will default to 25' },
            { name: 'page', type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'The page that is requested. When unspecified, ' \
                    'will load all employees.' }
          ]
        when 'employee_employee_benefit'
          [
            { name: 'employee_id', optional: false,
              extends_schema: true },
            { name: 'per', label: 'Limit', type: 'integer',
              control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'Number of employees per page. ' \
                    'When unspecified, will default to 25' },
            { name: 'page', type: 'integer', control_type: 'integer',
              render_input: 'integer_conversion',
              hint: 'The page that is requested. When unspecified, ' \
                    'will load all employees.' }
          ]
        when 'employee_termination'
          [{ name: 'employee_id', optional: false,
             extends_schema: true }]
        when 'company_company_benefit'
          [{ name: 'company_id', optional: false,
             extends_schema: true }]
        else
          []
        end
      end
    },
    search_object_output: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        if config_fields['object'] == 'pay_roll'
          [
            { name: 'records',
              label: config_fields['object'].pluralize.labelize,
              type: 'array', of: 'object',
              properties: call("#{config_fields['object']}_schema",
                               config_fields) }
          ]
        else
          [
            { name: 'records',
              label: config_fields['object'].pluralize.labelize,
              type: 'array', of: 'object',
              properties: call("#{config_fields['object']}_schema") }
          ]
        end
      end
    },
    get_object_input: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        if %w[company_contractor
              company_location].include? config_fields['object']
          [{ name: 'company_id', optional: false }]
        elsif config_fields['object'] == 'pay_roll'
          [
            { name: 'id', optional: false,
              label: "#{config_fields['object'].labelize} ID" },
            { name: 'company_id', optional: false },
            { name: 'include',
              control_type: 'multiselect', delimiter: ',',
              extends_schema: true,
              pick_list: [
                %w[Benefits benefits],
                %w[Deductions deductions],
                %w[Taxes taxes]
              ],
              hint: 'Returns payrolls and includes benefits, deductions, ' \
              'and taxes in employee_compensation. You can choose to ' \
              'include only what you need.' },
            { name: 'show_calculation',
              hint: 'with include, shows the tax, and/or benefit, and/or ' \
                    'deduction details for a calculated, unprocessed payroll.' }
          ]
        elsif config_fields['object'] == 'company_benefit'
          [
            { name: 'id', optional: false,
              label: "#{config_fields['object'].labelize} ID" },
            { name: 'company_id', sticky: true }
          ]
        elsif config_fields['object'].include?('company_') ||
              %w[time_off_request pay_roll pay_schedule pay_period].
                include?(config_fields['object'])
          [
            { name: 'id', optional: false,
              label: "#{config_fields['object'].labelize} ID" },
            { name: 'company_id', optional: false }
          ]
        elsif %w[employee_home_address
                 employee_job].include? config_fields['object']
          [
            { name: 'employee_id', optional: false }
          ]
        elsif config_fields['object'].include?('employee_') &&
              config_fields['object'] != 'employee_benefit'
          [
            { name: 'id', optional: false,
              label: "#{config_fields['object'].labelize} ID" },
            { name: 'employee_id', optional: false }
          ]
        else
          [{ name: 'id', optional: false,
             label: "#{config_fields['object'].labelize} ID" }]
        end
      end
    },
    get_object_output: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        if config_fields['object'] == 'pay_roll'
          call("#{config_fields['object']}_schema", config_fields)
        else
          call("#{config_fields['object']}_schema")
        end
      end
    },
    create_object_input: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        call("#{config_fields['object']}_create_schema")
      end
    },
    create_object_output: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        if %w[company_contractor company_location employee_job].
             include? config_fields['object']
          call("#{config_fields['object'].split('_')[1]}_schema")
        elsif config_fields['object'] == 'pay_roll'
          call("#{config_fields['object']}_schema", config_fields)
        else
          call("#{config_fields['object']}_schema")
        end
      end
    },
    update_object_input: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        call("#{config_fields['object']}_update_schema")
      end
    },
    update_object_output: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        if config_fields['object'] == 'pay_roll'
          call("#{config_fields['object']}_schema", config_fields)
        else
          call("#{config_fields['object']}_schema")
        end
      end
    },
    delete_object_input: {
      fields: lambda do |_connection, config_fields|
        next [] if config_fields.blank?

        [{ name: 'id', optional: false,
           label: "#{config_fields['object'].labelize} ID" }]
      end
    }
  },

  actions: {
    custom_action: {
      subtitle: 'Build your own Gusto action with a HTTP request',

      description: lambda do |object_value, _object_label|
        "<span class='provider'>" \
        "#{object_value[:action_name] || 'Custom action'}</span> in " \
        "<span class='provider'>Gusto</span>"
      end,

      help: {
        body: 'Build your own Gusto action with a HTTP request. ' \
        'The request will be authorized with your Gusto connection.',
        learn_more_url: 'https://docs.gusto.com/',
        learn_more_text: 'Gusto API documentation'
      },

      config_fields: [
        {
          name: 'action_name',
          hint: "Give this action you're building a descriptive name, e.g. " \
          'create record, get record',
          default: 'Custom action',
          optional: false,
          schema_neutral: true
        },
        {
          name: 'verb',
          label: 'Method',
          hint: 'Select HTTP method of the request',
          optional: false,
          control_type: 'select',
          pick_list: %w[get post put delete].
                       map { |verb| [verb.upcase, verb] }
        }
      ],

      input_fields: lambda do |object_definition|
        object_definition['custom_action_input']
      end,

      execute: lambda do |_connection, input|
        verb = input['verb']
        if %w[get post put patch options delete].exclude?(verb)
          error("#{verb.upcase} not supported")
        end
        path = input['path']
        data = input.dig('input', 'data') || {}
        if input['request_type'] == 'multipart'
          data = data.each_with_object({}) do |(key, val), hash|
            hash[key] = if val.is_a?(Hash)
                          [val[:file_content],
                           val[:content_type],
                           val[:original_filename]]
                        else
                          val
                        end
          end
        end
        request_headers = input['request_headers']
          &.each_with_object({}) do |item, hash|
          hash[item['key']] = item['value']
        end || {}
        request = case verb
                  when 'get'
                    get(path, data)
                  when 'post'
                    if input['request_type'] == 'raw'
                      post(path).request_body(data)
                    else
                      post(path, data)
                    end
                  when 'put'
                    if input['request_type'] == 'raw'
                      put(path).request_body(data)
                    else
                      put(path, data)
                    end
                  when 'patch'
                    if input['request_type'] == 'raw'
                      patch(path).request_body(data)
                    else
                      patch(path, data)
                    end
                  when 'options'
                    options(path, data)
                  when 'delete'
                    delete(path, data)
                  end.headers(request_headers)
        request = case input['request_type']
                  when 'url_encoded_form'
                    request.request_format_www_form_urlencoded
                  when 'multipart'
                    request.request_format_multipart_form
                  else
                    request
                  end
        response =
          if input['response_type'] == 'raw'
            request.response_format_raw
          else
            request
          end.
            after_error_response(/.*/) do |code, body, headers, message|
            error({ code: code, message: message,
                    body: body, headers: headers }.
              to_json)
          end

        response.after_response do |_code, res_body, res_headers|
          {
            body: res_body ? call('format_response', res_body) : nil,
            headers: res_headers
          }
        end
      end,

      output_fields: lambda do |object_definition|
        object_definition['custom_action_output']
      end
    },
    search_object: {
      title: 'Search records',
      subtitle: 'Retrieve a list of records, e.g. company, that matches ' \
                'your search criteria',
      description: lambda do |_connection, search_object_list|
        if %w[Employee Company].include?(search_object_list[:object])
          "Search <span class='provider'>" \
          "#{search_object_list[:object]&.pluralize || 'records'}</span> " \
          'in <span class="provider">Gusto</span> (Deprecated)'
        else
          "Search <span class='provider'>" \
          "#{search_object_list[:object]&.pluralize || 'records'}</span> " \
          'in <span class="provider">Gusto</span>'
        end
      end,

      help: lambda do |_connection, search_object_list|
        if %w[Employee Company].include?(search_object_list[:object])
          'The Search records action returns results that match ' \
          'all your search criteria.' \
          '<br>Note: The action is deprecated, please refrain from using. ' \
          '<a href = "https://gusto.stoplight.io/docs/api" target="blank">' \
          'Click here</a> for more details.'

        else
          'The Search records action returns results that match ' \
          'all your search criteria.'
        end
      end,
      config_fields: [
        {
          name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :search_object_list,
          hint: 'Select any Gusto object, e.g. <b>company</b>'
        }
      ],

      input_fields: lambda do |object_definitions|
        object_definitions['search_object_input']
      end,

      execute: lambda do |_connection, input|
        response = get(call('get_url', input), input.except('object'))&.
          after_error_response(/.*/) do |_code, body, _header, message|
            error("#{message}: #{body}") || []
          end

        if input['object'] == 'time_off_request'
          response.each do |record|
            record['days'] = record['days']&.map { |k, v| { day: k, hours: v } }
          end
        end
        { records: response }
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['search_object_output']
      end,

      sample_output: lambda do |_connection, input|
        { records: get(call('get_url', input)) }
      end,

      retry_on_response: [429],
      retry_on_request: %w[GET],
      max_retries: 3
    },
    get_object: {
      title: 'Get record details by ID',
      subtitle: 'Retrieves a specific record, e.g. <b>company</b> via ' \
                'its Gusto ID',
      description: lambda do |_connection, get_object_list|
        "Get <span class='provider'>#{get_object_list[:object] || 'record'}"\
        '</span> in <span class="provider">Gusto</span>'
      end,
      help: 'Retrieve the details of any standard or custom record, e.g. ' \
            'company, via its Gusto ID',
      config_fields: [
        {
          name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :get_object_list,
          hint: 'Select any Gusto object, e.g. <b>company</b>'
        }
      ],

      input_fields: lambda do |object_definitions|
        object_definitions['get_object_input']
      end,

      execute: lambda do |_connection, input|
        url = if %w[company_contractor employee_job
                    company_location].include? input['object']
                call('get_url', input)
              else
                "#{call('get_url', input)}/#{input['id']}"
              end
        response = get(url, input.except('object', 'id'))&.
          after_error_response(/.*/) do |_code, body, _header, message|
            error("#{message}: #{body}")
          end

        if input['object'] == 'time_off_request'
          response['days'] = response['days']&.
                               map { |k, v| { day: k, hours: v } }
        end
        if %w[company_contractor company_location
              employee_job].include? input['object']
          { 'records' => response }
        else
          response
        end
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['get_object_output']
      end,

      sample_output: lambda do |_connection, input|
        get(call('get_url', input))&.first
      end,

      retry_on_response: [429],
      retry_on_request: %w[GET],
      max_retries: 3
    },
    create_object: {
      title: 'Create record',
      subtitle: 'Creates a record, e.g. <b>company</b> in Gusto',
      description: lambda do |_connection, create_object_list|
        "Create <span class='provider'>" \
        "#{create_object_list[:object] || 'record'}</span> "\
        'in <span class="provider">Gusto</span>'
      end,
      help: 'Create any standard or custom record, e.g. company, in Gusto',
      config_fields: [
        {
          name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :create_object_list,
          hint: 'Select any Gusto object, e.g. <b>company</b>'
        }
      ],

      input_fields: lambda do |object_definitions|
        object_definitions['create_object_input']
      end,

      execute: lambda do |_connection, input|
        post(call('get_url', input), input.except('object'))&.
          after_error_response(/.*/) do |_code, body, _header, message|
            error("#{message}: #{body}")
          end
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['create_object_output']
      end,

      sample_output: lambda do |_connection, input|
        get(call('get_url', input))&.first
      end,

      retry_on_response: [429],
      retry_on_request: %w[POST],
      max_retries: 3
    },
    update_object: {
      title: 'Update record',
      subtitle: 'Update any standard or custom record, e.g. company, ' \
                'via its Gusto ID',
      description: lambda do |_connection, update_object_list|
        if update_object_list[:object] == 'Termination'
          "Update <span class='provider'>" \
          "#{update_object_list[:object] || 'record'}</span> "\
          'in <span class="provider">Gusto</span> (Deprecated)'
        else
          "Update <span class='provider'>" \
          "#{update_object_list[:object] || 'record'}</span> "\
          'in <span class="provider">Gusto</span>'
        end
      end,

      help: lambda do |_connection, update_object_list|
        if update_object_list[:object] == 'Payroll'
          "The payrolls are identified by their pay periods' start_date and " \
          'end_date. Both are required and must correspond with an existing, ' \
          'unprocessed payroll. If the dates do not match, the entire ' \
          'request will be rejected.'
        else
          'Update any standard or custom record, e.g. company, ' \
          'via its Gusto ID. First select the object, then specify the ' \
          'Gusto ID of the record to update'
        end
      end,

      config_fields: [
        {
          name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :update_object_list,
          hint: 'Select any Gusto object, e.g. <b>company</b>'
        }
      ],

      input_fields: lambda do |object_definitions|
        object_definitions['update_object_input']
      end,

      execute: lambda do |_connection, input|
        url = if input['object'] == 'employee_home_address'
                call('get_url', input)
              elsif input['object'] == 'pay_roll'
                "#{call('get_url', input)}/#{input.delete('start_date')}" \
                "/#{input.delete('end_date')}"
              else
                "#{call('get_url', input)}/#{input.delete('id')}"
              end
        put(url, input.except('object'))&.
          after_error_response(/.*/) do |_code, body, _header, message|
            error("#{message}: #{body}")
          end
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['update_object_output']
      end,

      sample_output: lambda do |_connection, input|
        get(call('get_url', input))&.first
      end,

      retry_on_response: [429],
      retry_on_request: %w[PUT],
      max_retries: 3
    },
    delete_object: {
      title: 'Delete record',
      subtitle: 'Deletes a record, e.g. <b>company</b> via its Gusto ID',
      description: lambda do |_connection, delete_object_list|
        "Delete <span class='provider'>" \
        "#{delete_object_list[:object] || 'record'}</span> "\
        'in <span class="provider">Gusto</span>'
      end,
      help: 'Delete any standard or custom record, e.g. company, ' \
            'via its Gusto ID. First select the object, then specify ' \
            'the Gusto ID of the record to delete',
      config_fields: [
        {
          name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :delete_object_list,
          hint: 'Select any Gusto object, e.g. <b>company</b>'
        }
      ],

      input_fields: lambda do |object_definitions|
        object_definitions['delete_object_input']
      end,

      execute: lambda do |_connection, input|
        delete("#{call('get_url', input)}/#{input.delete('id')}")&.
          after_error_response(/.*/) do |_code, body, _header, message|
            error("#{message}: #{body}")
          end
      end,

      retry_on_response: [429],
      retry_on_request: %w[GET],
      max_retries: 3
    }
  },

  pick_lists: {
    search_object_list: lambda do |_connection|
      [
        %w[Employee employee],
        %w[Company company],
        %w[Company\ employee company_employee],
        %w[Time\ off\ request time_off_request],
        %w[Payroll pay_roll],
        %w[Pay\ schedule pay_schedule],
        %w[Pay\ period pay_period],
        %w[Employee\ termination employee_termination],
        %w[Employee\ benefit employee_employee_benefit],
        %w[Company\ benefit company_company_benefit],
        %w[Benefit benefit]
      ]
    end,
    get_object_list: lambda do |_connection|
      [
        %w[Company company],
        %w[Company\ location company_location],
        %w[Company\ contractor company_contractor],
        %w[Contractor contractor],
        %w[Employee employee],
        %w[Employee\ home\ address employee_home_address],
        %w[Employee\ job employee_job],
        %w[Job job],
        %w[Time\ off\ request time_off_request],
        %w[Payroll pay_roll],
        %w[Pay\ schedule pay_schedule],
        %w[Employee\ termination termination],
        %w[Employee\ benefit employee_benefit],
        %w[Company\ benefit company_benefit]
      ]
    end,
    create_object_list: lambda do |_connection|
      [
        %w[Employee company_employee],
        %w[Contractor company_contractor],
        %w[Employee\ job employee_job],
        %w[Company\ location company_location],
        %w[Employee\ termination employee_termination],
        %w[Employee\ benefit employee_employee_benefit],
        %w[Company\ benefit company_company_benefit]
      ]
    end,
    update_object_list: lambda do |_connection|
      [
        %w[Employee employee],
        %w[Employee\ home\ address employee_home_address],
        %w[Contractor contractor],
        %w[Job job],
        %w[Payroll pay_roll],
        %w[Location location],
        %w[Employee\ termination termination],
        %w[Employee\ benefit employee_benefit],
        %w[Company\ benefit company_benefit]
      ]
    end,
    delete_object_list: lambda do |_connection|
      [
        %w[Employee\ benefit employee_benefit]
      ]
    end,
    custom_field_type_list: lambda do
      %w[text currency number date radio].map { |e| [e.labelize, e] }
    end,
    contribution_type_list: lambda do
      %w[amount percentage tiered].map { |e| [e.labelize, e] }
    end
  }
}
