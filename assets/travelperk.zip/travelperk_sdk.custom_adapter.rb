{
  title: "TravelPerk SDK",

  # API key authentication example. See more examples at https://docs.workato.com/developing-connectors/sdk/guides/authentication.html
  connection: {

    base_uri: lambda do
        'https://api.sandbox-travelperk.com/'
    end,

    authorization: {
      
      type: "oauth2",
      
      client_id: lambda do
        "6DrvwlyFrrJ2PpDrNgQtuYQpXjQWf7evuRrZpHwz"
      end,

      client_secret: lambda do
        "XoknndcSE3XrvnDX2HjRq2qae253A636idGvOteLWO18StY7OlDPUW02AR7ny9qBDSLKsUvF1eS9jPm9TUgjCCl7dvDfMyWIlyJWbRJwSI3zywUDkOoNZ4OKHnoxlRtk"
      end,

      authorization_url: lambda do |connection|
        "https://app.sandbox-travelperk.com/oauth2/authorize?response_type=code"
      end,

      token_url: lambda do |connection|
        'https://app.sandbox-travelperk.com/accounts/oauth2/token/'
      end,

      apply: lambda do |connection, access_token|
        headers("Authorization": "Bearer #{access_token}", "Api-Version": "1")
      end,     
      
      acquire: lambda do |connection, code| 
        response = post('https://app.sandbox-travelperk.com/accounts/oauth2/token/').payload(
              grant_type: 'authorization_code',
              client_id: "6DrvwlyFrrJ2PpDrNgQtuYQpXjQWf7evuRrZpHwz",
              client_secret: "XoknndcSE3XrvnDX2HjRq2qae253A636idGvOteLWO18StY7OlDPUW02AR7ny9qBDSLKsUvF1eS9jPm9TUgjCCl7dvDfMyWIlyJWbRJwSI3zywUDkOoNZ4OKHnoxlRtk",
              code: code
            ).request_format_www_form_urlencoded
        
        [
          { # This hash is for your tokens
            access_token: response["access_token"],
            refresh_token: response["refresh_token"],
          }
        ]

      end,

      refresh_on: [401, 403, 'Authentication credentials were not provided.'],

      refresh: lambda do |connection, refresh_token|
        response = post('https://app.sandbox-travelperk.com/accounts/oauth2/token/').
            payload(
              grant_type: 'refresh_token',
              client_id: "6DrvwlyFrrJ2PpDrNgQtuYQpXjQWf7evuRrZpHwz",
              client_secret: "XoknndcSE3XrvnDX2HjRq2qae253A636idGvOteLWO18StY7OlDPUW02AR7ny9qBDSLKsUvF1eS9jPm9TUgjCCl7dvDfMyWIlyJWbRJwSI3zywUDkOoNZ4OKHnoxlRtk",
              refresh_token: refresh_token
            ).request_format_www_form_urlencoded
       [
          {
            access_token: response["access_token"],
            refresh_token: response["refresh_token"]
          }
        ]
      end,
    }
  },
  object_definitions: {
  invoice_lines: {
      fields: lambda do |connection, config_fields|
      [
        {
          "control_type": "text",
          "label": "ID",
          "type": "string",
          "name": "id"
        },
        {
          "control_type": "text",
          "label": "Invoice Serial Number",
          "type": "string",
          "name": "invoice_serial_number"
        },
        {
          "control_type": "text",
          "label": "Expense Date",
          "render_input": "date_time_conversion",
          "parse_output": "date_time_conversion",
          "type": "date_time",
          "name": "expense_date"
        },
        {
          "control_type": "text",
          "label": "Description",
          "type": "string",
          "name": "description"
        },
        {
          "control_type": "number",
          "label": "Total Amount",
          "parse_output": "float_conversion",
          "type": "number",
          "name": "total_amount"
        },
        {
          "control_type": "text",
          "label": "Booker",
          "type": "string",
          "name": "booker"
        },
        {
          "control_type": "text",
          "label": "CostCenter",
          "type": "string",
          "name": "cost_center"
        },
        {
          "control_type": "text",
          "label": "Vendor",
          "type": "string",
          "name": "vendor"
        },
        {
          "control_type": "text",
          "label": "Currency",
          "type": "string",
          "name": "currency"
        },
      ]
      end
    },
  invoices: {
    fields: lambda do |connection, config_fields|
      [
        {
          "control_type": "text",
          "label": "PDF",
          "type": "string",
          "name": "pdf"
        },
     ]
    end
   }
  },
  actions: {
    get_invoice_lines: {
      execute: lambda do |connection, input|
        invoice_lines = get("#{connection['base_uri']}invoices/lines?issuing_date_gte=#{today + 1.days}&issuing_date_lte=#{today + 1.days}")['invoice_lines']
        
        connection['nilesh'] = 'new nilesh'
        
        puts connection
        
        flattened_invoice_lines = call(:flatten_invoice_lines, invoice_lines)

        flattened_invoice_lines
      end,
      output_fields: lambda do |object_definitions|
        [
          {
            name: "data",
            label: "Data",
            type: :array,
            of: :object,
            properties: object_definitions["invoice_lines"]
          }
        ]
      end
    },
    get_invoice: {
      input_fields: lambda do
        [
          {
            "control_type": "text",
            "label": "Invoie Serial Number",
            "name": "invoice_serial_number",
            "type": "string",
            "optional": false
          }
        ]
      end,
      execute: lambda do |connection, input|
        query_params = {
          'serial_number': input['invoice_serial_number']
        }
        invoices = get("#{connection['base_uri']}invoices", query_params)["invoices"]
        flattened_invoices = call(:flatten_invoices, invoices)
      end,
      output_fields: lambda do |object_definitions|
        [
          {
            name: "data",
            label: "Data",
            type: :array,
            of: :object,
            properties: object_definitions["invoices"]
          }
        ]
      end
    }
  },
  triggers: {
   new_message: {
      title: 'New message',

      subtitle: "Triggers when a message event is " \
      "received from Cisco Webex",

      description: lambda do |input, picklist_label|
        "New <span class='provider'>message event</span> in " \
        "<span class='provider'>Cisco Webex</span>"
      end,

      help: "Triggers when webhook is sent from Cisco.",

      input_fields: lambda do |object_definitions|
        [
          {
            name: "id",
            label: "Room ID"
          }
        ]
      end,

      webhook_subscribe: lambda do |webhook_url, connection, input|
          post("https://api.sandbox-travelperk.com/webhooks", {
            name: "invoice webhook",
            url: "https://postman-echo.com/post",
            secret: "some secret",
            events: [
              "invoice.issued"
            ]
          })
      end,

      webhook_notification: lambda do |input, payload, extended_input_schema, extended_output_schema, headers, params|
        payload["data"]
      end,

      webhook_unsubscribe: lambda do |webhook_subscribe_output, connection|
        delete("https://api.sandbox-travelperk.com/webhooks/#{webhook_subscribe_output['id']}")
      end,

      dedup: lambda do |message|
        message["id"]
      end,

      output_fields: lambda do |object_definitions|
        [
          {
            name: "id"
          },
          {
            name: "roomId"
          },
          {
            name: "personId"
          },
          {
            name: "personEmail"
          },
          {
            name: "created"
          }
        ]
      end
    },
   invoice_created: {
      title: 'New/updated Invoice',

      subtitle: "Triggers when invoice is created or " \
        "updated in travelperk",

      description: lambda do |input, picklist_label|
        "New/updated <span class='provider'>Invoice</span> " \
          "in <span class='provider'>Travelperk</span>"
      end,

      help: "Creates a expense in Fyle when Invoice are created or " \
        "updated in Travelperk. Each Invoice creates a separate Expense.",

      input_fields: lambda do |object_definitions|
        [
          {
            name: 'since',
            label: 'When first started, this recipe should pick up events from',
            type: 'timestamp',
            optional: true,
            sticky: true,
            hint: 'When you start recipe for the first time, it picks up ' \
              'trigger events from this specified date and time. Defaults to ' \
              'the current time.'
          }
        ]
      end,
      
      webhook_subscribe: lambda do |webhook_url, connection, input|
          post("https://api.sandbox-travelperk.com/webhooks").payload(
            name: "invoice webhook",
            targetUrl: "https://www.workato.com/users/940078/a7e9e4e5eb08b5378d982384c5f8dc39abebcf9f28ab795a5f228d2d9b5d9670/webhooks/notify/c65f98d3-1c20-4eab-acc7-0f07c258a295-travel_perk_connector_940078_1673853548",
            secret: "some secret",
            events: [
              "invoice.issued"
            ]
          )
      end,
    
    webhook_notification: lambda do |input, payload, extended_input_schema, extended_output_schema, headers, params|
      payload["data"]
      end,

    webhook_unsubscribe: lambda do |webhook_subscribe_output, connection|
      delete("https://api.sandbox-travelperk.com/webhooks/#{webhook_subscribe_output['id']}")
    end,

    output_fields: lambda do |object_definitions|
      [
        {
          name: "id"
        },
        {
          name: "roomId"
        },
        {
          name: "personId"
        },
        {
          name: "personEmail"
        },
        {
          name: "created"
        }
      ]
    end


  }
  },
  methods: {
    flatten_invoice_lines: lambda do |input|
      flattened_invoice_lines = []
      input.each { |invoice_line|
        flattened_invoice_lines.push({
          id: invoice_line["id"],
          invoice_serial_number: invoice_line["invoice_serial_number"],         
          expense_date: invoice_line["expense_date"],
          description: invoice_line["description"],
          vendor: invoice_line["metadata"]["vendor"] ? invoice_line["metadata"]["vendor"]["name"] : null,
          booker: invoice_line["metadata"]["booker"]["name"],
          cost_center: invoice_line["metadata"]["cost_center"],
          currency: invoice_line["currency"],
          total_amount: invoice_line["total_amount"],
        })
      }
      {
        data: flattened_invoice_lines
      }
    end,
  flatten_invoices: lambda do |input|
    flattened_invoices = []
    input.each { |invoice|
      flattened_invoices.push({
        pdf: invoice["pdf"]
      })
    }
    {
      data: flattened_invoices
    }
  end
  }
}